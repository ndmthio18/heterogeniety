from pathlib import Path
import json,hashlib
import pandas as pd
R=Path(__file__).resolve().parent;O=R/'results/comparison'
s=json.loads((O/'summary.json').read_text());v=json.loads((O/'terminal_verification.json').read_text());m=pd.read_csv(O/'evaporation_metrics.csv');p=pd.read_csv(O/'profile_metrics.csv');h={k:pd.read_csv(O/k/'spatial_history.csv') for k in ['fixed','coupled']}
def metric(lo,hi):return m[(m.model=='fixed')&(m.start_h==lo)&(m.end_h==hi)].iloc[0]
def rmse(k,side,t,band='interior_3_37'):return float(p[(p.model==k)&(p.side==side)&(p.time_h==t)&(p.band==band)].RMSE_mol_L.iloc[0])
def mdtable(headers,rows):return '| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+'\n'.join('| '+' | '.join(str(x) for x in row)+' |' for row in rows)
evap=mdtable(['窗口 / h','试验溶液失重 / g','模型 / g','相对偏差','区间率加权RMSE / (g/h)'],[[f'{int(r.start_h)}–{int(r.end_h)}',f'{r.experiment_g:.3f}',f'{r.model_g:.3f}',f'{r.error_percent:+.3f}%',f'{r.rate_RMSE_g_h:.6f}'] for r in m[m.model=='fixed'].itertuples()])
profiles=mdtable(['模型 / 时刻','粗砂整体RMSE','粗砂3–37mm RMSE','细砂整体RMSE','细砂3–37mm RMSE'],[[f'{k}, {t} h',*[f'{rmse(k,side,t,band):.6f}' for side in ['F36','W3'] for band in ['whole_0_40','interior_3_37']]] for k,t in [('uniform_v06',24),('coupled',24),('fixed',24),('coupled',60),('fixed',60),('fixed',174)]])
closure=mdtable(['砂层','总盐增量 / g','净底部供盐 / g','净界面流入 / g'],[[r['side'],*[f'{r[k]*58.4428:.6f}' for k in ['inventory_increase_mol','bottom_supply_mol','interface_in_mol']]] for r in s['salt_partition']])
downrows=[]
for k in ['coupled','fixed']:
 for t in [24,60,65+1/6,174]:
  q=h[k][abs(h[k].time_h-t)<1e-8]
  if len(q):
   r=q.iloc[0];downrows.append([f'{k}, {t:.3f} h',f'{r.F36_all_max_down_m_s:.6e}',f'{r.F36_core_max_down_m_s:.6e}',f'{r.F36_core_descending_volume_fraction*100:.3f}%'])
down=mdtable(['模型 / 时刻','全粗砂最大下行 / (m/s)','核心最大下行 / (m/s)','核心下行体积比例'],downrows)
report=f'''# RH=0固定孔隙率与渗透率：174 h完成报告

本独立v12已实际完成2 h预平衡＋174 h蒸发，退出码0，终态数值验收通过。关闭固盐对孔隙率和本征渗透率的反馈解决了本组诊断在旧65.28 h附近不能继续计算的问题；**没有证据表明共同时间窗的蒸发、浓度和下沉匹配因此整体改善**。1–174 h储液器溶液失重高估11.06%，174 h粗砂浓度明显低于所对照的MRI剖面。该结果支持区分数值可运行性与物理模型适用性。

## 文件

- [八页对比图](results/comparison/RH0_FIXED_174H_COMPARISON.pdf)：整体蒸发、盐量收支、粗细砂浓度、粗砂下沉、早期/共同/后期中心切面及偏心/水平切面。
- [蒸发主图](results/comparison/01_evaporation.png)、[浓度剖面](results/comparison/03_profiles.png)、[下沉过程](results/comparison/04_downflow.png)。
- 可复现代码：`finalize_extract.py`、`finalize_compare.py`、`write_final_report.py`；数据/误差/源哈希及视觉检查记录在`results/comparison/`。

## 1. 模型与验收范围

RH=0；等效气膜厚度8.100162249880822 mm；20°C等温；粗/细砂初始孔隙率0.40/0.36与本征渗透率7.819185772155931e−12/3.2034098778596945e−14 m²固定。相对渗透率仍随饱和度变化；溶液活度、密度、黏度及平衡析盐处理保留。没有总失水强制归一化，没有174 h重新率定，也没有纳入其他线程的非等温或厚度率定计算。原30720单元网格、300 s步长上限、600 s空间输出不变。

冻结binary SHA256：`6595025e48333062cfa05022d9f6d65670421d33f5fb6c92213c0a402a10b58e`。运行在liqin，完成UTC {v['status']['end_utc']}。24 h v08及57.5 h析盐前旧模型前缀通过。全程水/总盐/粗砂/细砂最大相对闭合残差分别为1.225e−12/1.415e−12/2.810e−12/2.035e−13；最大相对互补残差1.858e−16。这属于数值验收，并非全时窗网格/时间步收敛或物理验证。

最终1369个备份文件逐个重新计算SHA256通过；1057个空间场压缩档全部解压并比对原VTU SHA及字节数，PVD记录完全覆盖，最后时间633600 s（含2 h预平衡）。终态证据见`terminal_verification.json`。本地自动监控已完成归档后正常退出；Sonnet因组织403未能评审，验收与备份由确定性脚本执行，未将其描述为Claude已审阅。

## 2. 蒸发曲线：能继续计算，但后期偏高

主观测量为储液器**溶液失重**，与顶面纯水蒸发量分别展示。无0 h称重，以1 h为累计基准；原始称重完整展示到186 h，模型只到174 h。误差在真实相邻称重区间计算，不平移时钟、不补造实验值、不外推旧模型。

{evap}

1–24 h曾用于气膜率定，其符合不能作独立验证。24–174 h失重高估13.15%，60–174 h高估15.15%，即后期偏差更大。到旧模型最后接受时刻65.2832 h，新旧累计溶液损失仅差{s['old_new_loss_difference_at_old_end_g']:.6f} g；共同1–60 h累计偏差分别为4.2687%与4.2680%，不支持宣称改善。报告来源的表观mm/day曲线仍保留原时间标记，但不用于拟合或替代实际测量区间；换算保持1.002 g/cm³与19.64 cm²。

174 h顶面纯水蒸发率粗砂{s['coarse_final_mm_day']:.3f}、细砂{s['fine_final_mm_day']:.3f} mm/day，各按名义半圆面积；0–174 h累计粗砂/细砂份额为{s['coarse_cumulative_water_share']*100:.3f}% / {(1-s['coarse_cumulative_water_share'])*100:.3f}%。局部份额没有两砂独立蒸发实测可验证。

## 3. 固盐及分砂盐量闭合

首个接受步固盐总量>1e−12 mol在{s['first_accepted_solid_h']:.6f} h，前步57.5 h；首个保存空间场对应{s['first_saved_solid_h']:.6f} h。两者不同是因为求解步与场输出频率不同。174 h固盐{s['solid_g']:.6f} g，全部细砂；溶解盐{s['dissolved_g']:.6f} g；两者之和才是样品总盐。平衡析盐时间不等于实验成核时间。

{closure}

正号为流入该砂；粗砂主要获得底部供盐，再净向细砂输出。界面对流0.0431770 mol由粗向细，扩散−0.0202185 mol反向抵消，净交换0.0229586 mol，不能把净量当作全部输运强度。上表四舍五入未显示±9.09213e−9 mol初始扰动分配，代码显式保留，其后分砂闭合绝对误差≤4.75e−14 mol。MRI仅给溶解态信号，不能直接拿来闭合包含固盐的总量，也不能由模型闭合推断MRI必然低估。

本对照的最大等效固盐体积变量达到{s['max_solid_equivalent_volume']:.6f}，已远超原孔隙容量且超过1。它在当前固定反馈诊断中仅代表等效库存；**不是实际几何体积分数，也不能解释成孔内占据或外部盐壳形态**。能跑到174 h不能消除这一物理适用边界。

## 4. 浓度分布与旧版本的差异

以下RMSE单位均为mol/L；整体统计0–40 mm，内部统计3–37 mm，二者都来自各砂整半截面的1 mm层平均。未使用虚构的中心ROI。MRI为已见过、但未用于本次参数拟合的空间对照，不称盲验证。

{profiles}

固定孔隙/K前后24 h剖面完全一致；60 h误差变化仅约1e−6至4e−5 mol/L，不应在没有新增收敛分析时称有意义的改进。与更早均匀蒸发v06相比，24 h粗砂内部RMSE略降、细砂内部RMSE增大，整体误差也未一致降低。v06是不同蒸发边界的历史参考，不能把全部差异归因于本次固定反馈。

174 h粗砂内部RMSE为1.223719 mol/L，平均偏差−1.215502 mol/L：模型未再现MRI显示的粗砂整体浓度抬升。细砂内部RMSE为0.205039 mol/L，剖面主体较近，但表层差异仍存在。不能以细砂后期较近掩盖粗砂偏差，也不能据此断言实验错了。精确MRI体素处理、32 min采集窗口、名义时钟及对固盐不可见的观测算子限制仍在；它们本轮未重新估计或率定。

## 5. 粗砂下沉过程

{down}

核心区域排除壁面/上下边界5 mm、界面3 mm；速度来自守恒通量重建的内部LS速度。下行体积统计阈值为1e−8 m/s，只是固定诊断，不是线性失稳或MRI可见下沉起始。0–4 h保留全部场输出，此后每小时并补充共同快照，故不重新估计“连续三帧起始”。旧模型完整曲线没有外推到174 h。

在共同时间窗，新旧下沉曲线基本重合。174 h全粗砂/核心最大下行分别为1.00814e−6/4.50802e−7 m/s，核心超过阈值的体积为25.722%。140 h附近强度有峰值，随后减弱；这说明固定模型内部演化，不能称比旧模型更符合实验，因为旧模型没有相同时刻输出，也没有同定义的实验速度场。

## 6. 图像检查后的空间解释

2与4 h中心切面：两模型均以顶部浓缩层为主，早期两组色块在共同色标下重合；24 h及57.5 h全场浓度差分别≤2.62e−13和8.33e−14 mol/L。60与65.1667 h的主要浓缩结构仍在细砂上部，两组宏观形态接近；但65.1667 h局部最大浓度差已达0.201289 mol/L，因此不能将“整体剖面/曲线接近”说成所有局部场完全相同。

固定模型96、108、174 h中心切面表现为细砂上部高浓度区，界面细砂侧出现相对同层平均值偏低的带状区域，较远离界面的细砂上部偏高。24/174 h的z=±10 mm偏心切面及10/25 mm深度水平面显示，这一界面附近异常并非仅在中心切面出现。两偏心切面仍近似对称，不能据此宣称已复现实验的非对称三维指进。粗砂存在模型下行循环，而其整半截面后期浓度偏低；有下沉流动不等于预测了正确的盐量与浓度演变。

## 7. 只用蒸发率讨论实验析盐时间

遵照用户要求，实验起始推断仅引用`analysis/evaporation_only_onset_20261102`的原始称重速率分析。40–60 h只是条件性的速率斜率变化候选，强烈依赖分析窗口与候选函数，不能作为已验证结晶时刻或率定目标。未采用MRI浓度变化或章稿96–108 h窗口确定本报告的实验起始。模型57.58 h落在该候选附近，不能据此验证成核处理；单独的蒸发速率变化也不能唯一识别盐结晶。

## 8. 可支持的结论与后续方向

当前可支持：移除固盐对孔隙/K反馈后，按相同气膜和等温设定可以守恒地推进到174 h；早期和共同窗基本保留旧结果；后期蒸发偏高、粗砂浓度偏低仍未解决。不能支持：析盐模型已被验证、实验MRI必然低估、固定孔隙/K更符合所有实验现象，或真实成核发生于57.58 h。

下一步应首先对已经独立启动的非等温/气膜案例使用同一观测口径完成比较，再判断外部传质、热反馈、底部供给及界面输运各自的贡献；不能用额外自由参数同时追逐总失重、MRI和起始时间。本次没有改动这些其他计算。外部盐壳几何、成核延迟及全时窗数值收敛仍未解决。
'''
(R/'FIXED_HYDRAULICS_174H_REPORT.md').write_text(report,encoding='utf-8')
print('Wrote',R/'FIXED_HYDRAULICS_174H_REPORT.md')
